Some JavaScript snippets that I have done in order to learn and have some reference for future developments.

[@davoclavo](http://twitter.com/davoclavo)
